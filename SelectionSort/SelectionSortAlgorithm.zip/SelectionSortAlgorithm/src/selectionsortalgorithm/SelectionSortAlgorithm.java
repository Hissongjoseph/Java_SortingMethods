/*
Program title: Selection Sort Algorithm
Programmer: Joseph Hissong
Course: CSCI 192
Semester: Fall 2015
Instructor: Samimi
Due Date: December 4, 2015

Description: This program takes inputted numbers and sorts using selection
sort. Any numbers under zero and above one thousand will be send to a external 
text file named InvalidData and will be prompted with an appropriate message.

input:Amount of numbers to sort & the numbers to sort.
Output: N/A
*/
package selectionsortalgorithm;
import java.util.Scanner;
import java.util.Formatter;
public class SelectionSortAlgorithm {  
    public static void main(String[] args) throws Exception {
    
    int Counter = 0;
    int[] Array = getData();
    System.out.println("******************************************************************************");
    Array = SelectionSortData(Array,Counter);//calls the selection sort method 
    }//end of Main String

    private static int[] getData() throws Exception {
    Scanner input = new Scanner(System.in);
    Formatter output = new Formatter("InvalidData.out");
    
    int AmountOfNumbers = 0;
    
    System.out.println("Please enter how many numbers you would like to sort:");
    AmountOfNumbers = input.nextInt();
    int[] Array = new int[AmountOfNumbers];
    
    
    System.out.println("Please enter numbers greater than 0 and less than 1000 separated by spaces: ");
    for (int i = 0; i < AmountOfNumbers;i++)
    {
        
        Array[i]= input.nextInt();
        while (Array[i] > 1000 || Array[i] < 0) //checks user input to make sure it is between 0 and 1000.
        {
        System.out.println("Your input does not match the criteria, please enter a number between 0 and 1000");
        output.format("Invalid Criteria that has been entered: %d \n",Array[i]);//sends output to output file.
        
        while(!input.hasNextInt())
            {
            input.next() ;
            }//end of input while loop
        Array[i] = input.nextInt();
        }//end of while loop
   
    }//end of for loop
    output.close();
    return Array;
    }//end of getData

    private static int[] SelectionSortData(int[] Array,int Counter) {
    
    for (int i = 0;i < Array.length;i++)
    {
        int first = i;
        for (int p = i + 1;p < Array.length; p++)
            if (Array[p] < Array[first])
                first = p;
        
        int Small = Array[first];
        Array[first] = Array[i];
        Array[i] = Small;
        Counter++;//counter for number of passes
    }//end of for loop
    System.out.printf("Amount of times For-loop was executed: %d%n",Counter);
    //displays how many times the sort method had to go through
    return Array;
    }//end of SelectionSortData
    
}
